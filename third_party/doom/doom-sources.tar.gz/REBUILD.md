# Doom erneut bauen

Python 3 und die in build.json benannte Arm-GNU-Toolchain bereitstellen.
Das gesamte Archiv in ein neues Verzeichnis außerhalb eines Git-Repos entpacken.
Keine Enginequelle herunterladen und kein Git-Repository anlegen.

```sh
python3 gelumpe/tools/doom/rebuild_runtime.py \
  --toolchain "$doom_toolchain" --output "$doom_rebuild"
```

Der Befehl prüft alle archivierten Quellen, Compiler und Toolchainmanifest,
übernimmt SRC_DOOM aus dem archivierten Makefile und versetzt Quellpfade.
Er baut nur aus diesem Archiv, vergleicht den Binärhash mit build.json
und bricht bei Abweichung ab. Ergebnis steht in rebuild.json.
Compiler, Laufzeitbibliotheken und deren Lizenzprüfung sind separat bereitzustellen.
redistribution_ready bleibt false; dieses Archiv ist keine Distributionsfreigabe.
